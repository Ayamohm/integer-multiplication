﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Problem
{

    // ***************
    // DON'T CHANGE CLASS OR FUNCTION NAME
    // YOU CAN ADD FUNCTIONS IF YOU NEED TO
    // ***************
    public static class IntegerMultiplication
    {
        private static byte[] plus(byte[] x, byte[] y)
        {
            int n = Math.Min(x.Length, y.Length);
            byte[] R = new byte[n];

            byte C = 0;
            int i = 0;
            while (i <= n - 1)
            {
                int e = x[i] + y[i] + C;
                byte total = (byte)e;
                R[i] = (byte)(total % 10);
                int ce = total / 10;
                C = (byte)ce;
                i++;
            }
            return R;
        }
        public static byte[] Sub(byte[] X, byte[] Y)
        {
            int n = Math.Min(X.Length, Y.Length);
            byte[] R = new byte[n];

            int B = 0;
            int i = 0;
            while (i <= n - 1)
            {
                int D = X[i + X.Length - n] - Y[i + Y.Length - n] - B;
                if (D < 0)
                {
                    D += 10;
                    B = 1;
                }
                else
                {
                    B = 0;
                }
                R[i] = (byte)D;
                i++;
            }
            return R;
        }

        static public byte[] ShiftLeft_function(byte[] X, int k)
        {
            int n = X.Length;
            byte[] result = new byte[n + k];
            for (int i = 0; i < n; i++)
            {
                result[i + k] = X[i];
            }
            return result;
        }
                public static void print(byte[] x)
        {
            int n=x.Length;
            for(int i = n - 1; i >= 0; i--)
            {
                Console.WriteLine(x[i]);
            }
            Console.WriteLine();
        }
        static public byte[] IntegerMultiply(byte[] X, byte[] Y, int N)
        {
            if (N <= 32)
            {
                byte[] re11 = new byte[2 * N];
                int i = 0;
                while (i < X.Length)
                {
                    byte CARRY = 0;
                    int j = 0;
                    while (j < Y.Length)
                    {
                        int multy = X[i] * Y[j] + CARRY + re11[i + j];
                        re11[i + j] = (byte)(multy % 10);
                        int c = multy / 10;
                        CARRY = (byte)c;
                        j++;
                    }
                    re11[Y.Length + i] = (CARRY);
                    i++;
                }
                return re11;
            }
            int n = 0;
            if (X.Length > Y.Length)
            {
                n = X.Length;
            }
            else
            {
                n = Y.Length;
            }
            if (X.Length % 2 != 0)
            {
                Array.Reverse(X);
                X = ShiftLeft_function(X, 1);
                Array.Reverse(X);
            }
            if (Y.Length % 2 != 0)
            {
                Array.Reverse(Y);
                Y = ShiftLeft_function(Y, 1);
                Array.Reverse(Y);
            }
            if (X.Length > Y.Length)
            {
                int sub1 = X.Length - Y.Length;
                for (int i = 0; i < sub1; i++)
                {
                    Y = ShiftLeft_function(Y, sub1);
                }
            }
            if (X.Length < Y.Length)
            {
                int sub2 = Y.Length - X.Length;
                for (int i = 0; i < sub2; i++)
                {
                    X = ShiftLeft_function(Y, sub2);
                }
            }
            int half = n / 2;
            byte[] result = new byte[2 * n];
            //split X
            byte[] x1 = new byte[half];
            byte[] x2 = new byte[half];

            Array.Copy(X, 0, x1, 0, half);
            Array.Copy(X, half, x2, 0, half);

            //split Y
            byte[] y1 = new byte[half];
            byte[] y2 = new byte[half];

            Array.Copy(Y, 0, y1, 0, half);
            Array.Copy(Y, half, y2, 0, half);

            //byte[] x2yx = IntegerMultiply(x2, y2, half);
            //byte[] x1y1 = IntegerMultiply(x1, y1, half);
            byte[] x2yx = new byte[half];
            byte[] x1y1 = new byte[half];
            Parallel.Invoke(() => x1y1 = IntegerMultiply(x1, y1, half), () => x2yx = IntegerMultiply(x2, y2, half));
            byte[] x1x2 = plus(x1, x2);
            byte[] y1y2 = plus(y1, y2);

            byte[] a_plus_b_c_plus_d = IntegerMultiply(x1x2, y1y2, half); //(a+b)(c+d)
            byte[] Z1 = Sub(a_plus_b_c_plus_d, x1y1);
            byte[] Z2 = Sub(Z1, x2yx); //z-ac-bd

            Array.Reverse(Z2);
            byte[] r_z1 = ShiftLeft_function(Z2, N / 2);
            Array.Reverse(r_z1);

            Array.Reverse(x2yx); //for loop
            byte[] r_XY = ShiftLeft_function(x2yx, N);
            Array.Reverse(r_XY);

            byte[] new_z = new byte[half + r_z1.Length];
            byte[] new_bd = new byte[n + r_XY.Length];

            for (int i = 0; i < r_z1.Length; i++)
            {
                new_z[half + i] = r_z1[i];
            }
            for (int i = 0; i < r_XY.Length; i++)
            {
                new_bd[n + i] = r_XY[i];
            }

            byte[] new_ZBD = plus(new_z, new_bd);
            result = plus(new_ZBD, x1y1);
            print(result);
            return result;
        }
    }
}
